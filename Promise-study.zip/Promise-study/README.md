# 自定义 Promise

> Promise.js 是 ES5 function 实现 Promise 的完整版

> Promise_class.js 是 ES6 class 实现 Promise 的完整版

> then.js 是第二次重写的 then()方法

> 自定义 Promise.html 文件用来测试

点击这里看->[Promise 学习笔记](http://www.woc12138.com/article/43)
